## Introduction

This published dataset was measured by impulse radio UWB (IR-UWB) through-wall radar system. Three test subjects were measured in different environments and several defined motion statuses.

Some symbols are described as follow:

| Symbols |  Description   |
| :-----: | :------------: |
|   001   | Human Walking  |
|   010   | Standing still |
|   100   |     Empty      |
|   H1    | Volunteer NO.1 |
|   H2    | Volunteer NO.2 |
|   H3    | Volunteer NO.3 |

More detail can obtain from the pre-print in Arxiv.

《A dataset of human motion status using IR-UWB through wall radar》



